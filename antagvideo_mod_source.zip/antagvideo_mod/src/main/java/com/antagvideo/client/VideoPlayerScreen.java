package com.antagvideo.client;

import com.antagvideo.AntagVideoMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class VideoPlayerScreen extends Screen {
    private static final Identifier SOUND_ID = Identifier.of(AntagVideoMod.MOD_ID, "antag_video");
    private final String videoName;
    private final String playerName;
    private long startTime = 0L;
    private boolean soundStarted = false;
    private final VideoRenderer renderer;

    public VideoPlayerScreen(String videoName, String playerName) {
        super(Text.literal("Playing: " + videoName));
        this.videoName = videoName;
        this.playerName = playerName;
        this.renderer = new VideoRenderer();
    }

    @Override
    protected void init() {
        super.init();
        // Record start time only on initial open (prevents audio-video desync if window is resized or F11 pressed)
        if (this.startTime == 0L) {
            this.startTime = System.currentTimeMillis();
        }
        if (!soundStarted) {
            try {
                MinecraftClient.getInstance().getSoundManager().play(
                    PositionedSoundInstance.master(SoundEvent.of(SOUND_ID), 1.0f, 1.0f)
                );
            } catch (Exception e) {
                AntagVideoMod.LOGGER.warn("Could not play sound: " + e.getMessage());
            }
            soundStarted = true;
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Full black background for cinematic feel
        context.fill(0, 0, this.width, this.height, 0xFF000000);

        double time = (System.currentTimeMillis() - startTime) / 1000.0;
        renderer.render(context, this.width, this.height, time, videoName, playerName);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void tick() {
        super.tick();
        // Auto-close cleanly after video length (~43.5s allows last frame and audio to complete)
        if (startTime > 0L && (System.currentTimeMillis() - startTime > 43500)) {
            this.close();
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) { // ESC to skip
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        // Stop sound cleanly when skipped or finished
        try {
            MinecraftClient.getInstance().getSoundManager().stopSounds(SOUND_ID, null);
        } catch (Exception e) {
            AntagVideoMod.LOGGER.warn("Could not stop sound: " + e.getMessage());
        }
        super.close();
    }
}
