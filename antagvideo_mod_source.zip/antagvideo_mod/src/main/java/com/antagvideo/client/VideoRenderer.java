package com.antagvideo.client;

import com.antagvideo.AntagVideoMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.resource.Resource;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Loads and plays sequential JPEG frames.
 * Frames are expected at: assets/antagvideo/textures/frames/0001.jpg, 0002.jpg, ...
 */
public class VideoRenderer {
    private static final int TOTAL_FRAMES = 343; // Full 42.84s video at 8 FPS
    private static final double FPS = 8.0;
    private static final double VIDEO_DURATION = 42.84;

    // Cache loaded textures so we don't reload every frame
    private final Map<Integer, Identifier> textureCache = new HashMap<>();
    private int lastLoadedFrame = -1;

    public void render(DrawContext context, int screenWidth, int screenHeight, double timeSeconds, String videoName, String playerName) {
        int frameIndex = (int)(timeSeconds * FPS) + 1;
        if (frameIndex < 1) frameIndex = 1;
        if (frameIndex > TOTAL_FRAMES) frameIndex = TOTAL_FRAMES;

        Identifier tex = getOrLoadFrame(frameIndex);

        if (tex != null) {
            // Maintain cinematic aspect ratio (854:392) without stretching
            double videoAspect = 854.0 / 392.0;
            double screenAspect = (double) screenWidth / (double) screenHeight;
            int drawW, drawH, drawX, drawY;

            if (screenAspect > videoAspect) {
                drawH = screenHeight;
                drawW = (int) Math.round(screenHeight * videoAspect);
                drawX = (screenWidth - drawW) / 2;
                drawY = 0;
            } else {
                drawW = screenWidth;
                drawH = (int) Math.round(screenWidth / videoAspect);
                drawX = 0;
                drawY = (screenHeight - drawH) / 2;
            }

            context.drawTexture(tex, drawX, drawY, 0, 0, drawW, drawH, drawW, drawH);
        } else {
            // Fallback dark screen
            context.fill(0, 0, screenWidth, screenHeight, 0xFF0D0D0D);
            context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer,
                Text.literal("§cFailed to load frame " + frameIndex), 20, screenHeight / 2 - 10, 0xFF5555);
        }

        // Progress bar
        int barHeight = 4;
        int progress = (int) Math.min(screenWidth, (timeSeconds / VIDEO_DURATION) * screenWidth);
        context.fill(0, screenHeight - barHeight, progress, screenHeight, 0xFF00E676);
        context.fill(progress, screenHeight - barHeight, screenWidth, screenHeight, 0xFF1A1A1A);

        // HUD text
        var tr = MinecraftClient.getInstance().textRenderer;
        String info = "§e" + videoName + " §7→ §b" + playerName + "  §8| §f" + String.format("%.1fs", timeSeconds);
        context.drawTextWithShadow(tr, Text.literal(info), 8, 8, 0xFFFFFF);

        context.drawTextWithShadow(tr, Text.literal("§8Frame " + frameIndex + "/" + TOTAL_FRAMES + "  §7[ESC to skip]"), 8, 22, 0xAAAAAA);
    }

    private Identifier getOrLoadFrame(int frameIndex) {
        if (textureCache.containsKey(frameIndex)) {
            return textureCache.get(frameIndex);
        }

        // Try to load the JPEG as NativeImage and register a DynamicTexture
        String path = String.format("textures/frames/%04d.jpg", frameIndex);
        Identifier id = Identifier.of(AntagVideoMod.MOD_ID, path);

        try {
            MinecraftClient client = MinecraftClient.getInstance();
            Optional<Resource> resource = client.getResourceManager().getResource(id);

            if (resource.isPresent()) {
                try (InputStream stream = resource.get().getInputStream()) {
                    NativeImage image = NativeImage.read(stream);
                    NativeImageBackedTexture texture = new NativeImageBackedTexture(image);
                    Identifier dynamicId = Identifier.of(AntagVideoMod.MOD_ID, "dynamic_frame_" + frameIndex);
                    client.getTextureManager().registerTexture(dynamicId, texture);
                    textureCache.put(frameIndex, dynamicId);
                    return dynamicId;
                }
            } else {
                AntagVideoMod.LOGGER.warn("Frame not found in resources: " + path);
            }
        } catch (Exception e) {
            AntagVideoMod.LOGGER.error("Failed to load frame " + frameIndex + ": " + e.getMessage());
        }

        // Fallback: try the raw identifier (sometimes works for PNG)
        textureCache.put(frameIndex, id);
        return id;
    }
}
