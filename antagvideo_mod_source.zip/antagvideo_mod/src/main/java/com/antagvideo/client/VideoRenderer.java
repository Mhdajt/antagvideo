package com.antagvideo.client;

import com.antagvideo.AntagVideoMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * High-performance, cinematic video cutscene renderer.
 * 
 * - Full 343 sequential frames (0001.jpg -> 0343.jpg) at 8 FPS
 * - Frame-perfect audio synchronization via elapsed time mapping
 * - Letterboxing / Pillarboxing maintaining exact native aspect ratio (2.178:1)
 * - Zero runtime GC allocations (statically pre-allocated Identifier table)
 * - Sleek, non-intrusive cinematic overlay (subtle bottom progress line & intro fade-out)
 */
public class VideoRenderer {
    public static final int TOTAL_FRAMES = 343;
    public static final double VIDEO_DURATION = 42.84;
    public static final double FPS = TOTAL_FRAMES / VIDEO_DURATION; // ~8.0065 fps
    
    // Native frame dimensions: 854 x 392 (2.17857 : 1)
    public static final double ASPECT_RATIO = 854.0 / 392.0;

    // Pre-allocated texture identifiers for all 343 frames to eliminate runtime GC allocations
    private static final Identifier[] FRAMES = new Identifier[TOTAL_FRAMES];

    static {
        for (int i = 0; i < TOTAL_FRAMES; i++) {
            String path = String.format("textures/frames/%04d.jpg", i + 1);
            FRAMES[i] = Identifier.of(AntagVideoMod.MOD_ID, path);
        }
    }

    public void render(DrawContext context, int screenWidth, int screenHeight, double timeSeconds, String videoName, String playerName) {
        // 1. Calculate frame index strictly based on elapsed real-time (stays in 100% sync with audio)
        int frameIndex = (int) (timeSeconds * FPS);
        if (frameIndex < 0) {
            frameIndex = 0;
        } else if (frameIndex >= TOTAL_FRAMES) {
            frameIndex = TOTAL_FRAMES - 1;
        }

        Identifier currentTexture = FRAMES[frameIndex];

        // 2. Aspect Ratio Math: Letterbox or Pillarbox to preserve true 2.178:1 aspect ratio without stretching
        double screenAspect = (double) screenWidth / (double) screenHeight;
        int renderWidth;
        int renderHeight;
        int renderX;
        int renderY;

        if (screenAspect > ASPECT_RATIO) {
            // Ultrawide screen: match screen height, pillarbox left & right
            renderHeight = screenHeight;
            renderWidth = (int) Math.round(screenHeight * ASPECT_RATIO);
            renderX = (screenWidth - renderWidth) / 2;
            renderY = 0;
        } else {
            // Standard / narrow screen (16:9, 16:10, 4:3): match screen width, letterbox top & bottom
            renderWidth = screenWidth;
            renderHeight = (int) Math.round(screenWidth / ASPECT_RATIO);
            renderX = 0;
            renderY = (screenHeight - renderHeight) / 2;
        }

        // Draw the current video frame
        try {
            context.drawTexture(currentTexture, renderX, renderY, 0, 0, renderWidth, renderHeight, renderWidth, renderHeight);
        } catch (Exception e) {
            // Graceful fallback to black if texture loading has a momentary delay
            context.fill(renderX, renderY, renderX + renderWidth, renderY + renderHeight, 0xFF000000);
        }

        // 3. Cinematic Progress Bar: A clean, sleek 3px accent line at the bottom
        int barHeight = 3;
        int progressWidth = (int) Math.min(screenWidth, (timeSeconds / VIDEO_DURATION) * screenWidth);
        if (progressWidth > 0) {
            context.fill(0, screenHeight - barHeight, progressWidth, screenHeight, 0xFFE50914); // Crimson cinematic accent
        }
        context.fill(progressWidth, screenHeight - barHeight, screenWidth, screenHeight, 0x44000000); // Translucent track

        // 4. Subtle Intro HUD: Shows video title & ESC skip prompt for the first 3.5s, then smoothly fades out for full immersion
        if (timeSeconds < 3.5) {
            float alpha = 1.0f;
            if (timeSeconds > 2.5) {
                alpha = (float) (1.0 - (timeSeconds - 2.5)); // Fade out during the last second
            }
            int alphaInt = (int) (alpha * 255.0f);
            if (alphaInt > 4) {
                int titleColor = (alphaInt << 24) | 0x00FFFFFF;
                int subColor = (alphaInt << 24) | 0x00AAAAAA;

                var textRenderer = MinecraftClient.getInstance().textRenderer;
                String title = "▶ " + videoName + " • " + playerName;
                context.drawTextWithShadow(textRenderer, Text.literal(title), 16, 16, titleColor);
                context.drawTextWithShadow(textRenderer, Text.literal("[ESC to skip]"), screenWidth - 90, 16, subColor);
            }
        }
    }
}
