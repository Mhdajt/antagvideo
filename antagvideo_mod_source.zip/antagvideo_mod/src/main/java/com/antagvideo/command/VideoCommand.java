package com.antagvideo.command;

import com.antagvideo.client.VideoPlayerScreen;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class VideoCommand {
    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher, net.minecraft.command.CommandRegistryAccess registryAccess) {
        dispatcher.register(literal("videoplay")
            .then(argument("video", StringArgumentType.string())
                .then(argument("player", StringArgumentType.string())
                    .executes(ctx -> {
                        String videoName = StringArgumentType.getString(ctx, "video");
                        String playerName = StringArgumentType.getString(ctx, "player");
                        
                        MinecraftClient client = MinecraftClient.getInstance();
                        client.execute(() -> {
                            client.setScreen(new VideoPlayerScreen(videoName, playerName));
                        });
                        
                        ctx.getSource().sendFeedback(Text.literal("§aPlaying video §e" + videoName + " §afor §e" + playerName));
                        return 1;
                    })
                )
            )
        );

        dispatcher.register(literal("videostop")
            .executes(ctx -> {
                MinecraftClient client = MinecraftClient.getInstance();
                if (client.currentScreen instanceof VideoPlayerScreen) {
                    client.execute(() -> client.setScreen(null));
                    ctx.getSource().sendFeedback(Text.literal("§cVideo stopped"));
                }
                return 1;
            })
        );
    }
}
