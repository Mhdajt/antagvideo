package com.antagvideo.command;

import com.antagvideo.client.VideoPlayerScreen;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class VideoCommand {

    // Available videos
    private static final String[] AVAILABLE_VIDEOS = {"Intro"};

    private static final SuggestionProvider<FabricClientCommandSource> VIDEO_SUGGESTIONS = (context, builder) -> {
        return CommandSource.suggestMatching(AVAILABLE_VIDEOS, builder);
    };

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher, net.minecraft.command.CommandRegistryAccess registryAccess) {
        
        // /videoplay  → shows help + list
        dispatcher.register(literal("videoplay")
            .executes(ctx -> {
                ctx.getSource().sendFeedback(Text.literal("§6=== Video Player ==="));
                ctx.getSource().sendFeedback(Text.literal("§eUsage: §f/videoplay <video> <player>"));
                ctx.getSource().sendFeedback(Text.literal("§eExample: §a/videoplay Intro Steve"));
                ctx.getSource().sendFeedback(Text.literal("§7Available videos:"));
                for (String v : AVAILABLE_VIDEOS) {
                    ctx.getSource().sendFeedback(Text.literal("  §b- " + v));
                }
                ctx.getSource().sendFeedback(Text.literal("§7Type §f/videostop §7to stop"));
                return 1;
            })
            .then(argument("video", StringArgumentType.string())
                .suggests(VIDEO_SUGGESTIONS)
                .then(argument("player", StringArgumentType.string())
                    .executes(ctx -> {
                        String videoName = StringArgumentType.getString(ctx, "video");
                        String playerName = StringArgumentType.getString(ctx, "player");

                        // Check if video exists
                        boolean found = false;
                        for (String v : AVAILABLE_VIDEOS) {
                            if (v.equalsIgnoreCase(videoName)) {
                                found = true;
                                videoName = v; // normalize
                                break;
                            }
                        }

                        if (!found) {
                            ctx.getSource().sendFeedback(Text.literal("§cUnknown video: §e" + videoName));
                            ctx.getSource().sendFeedback(Text.literal("§7Available: §bIntro"));
                            return 0;
                        }

                        MinecraftClient client = MinecraftClient.getInstance();
                        String finalVideoName = videoName;
                        client.execute(() -> {
                            client.setScreen(new VideoPlayerScreen(finalVideoName, playerName));
                        });

                        ctx.getSource().sendFeedback(Text.literal("§a▶ Playing §e" + videoName + " §afor §b" + playerName));
                        return 1;
                    })
                )
            )
        );

        // /videostop
        dispatcher.register(literal("videostop")
            .executes(ctx -> {
                MinecraftClient client = MinecraftClient.getInstance();
                if (client.currentScreen instanceof VideoPlayerScreen) {
                    client.execute(() -> client.setScreen(null));
                    ctx.getSource().sendFeedback(Text.literal("§c⏹ Video stopped"));
                } else {
                    ctx.getSource().sendFeedback(Text.literal("§7No video is currently playing"));
                }
                return 1;
            })
        );
    }
}
