# Antag Video Cutscene Mod (Fabric 26.2)

Fullscreen high-quality video cutscene player for Minecraft.

## Features
- **Cinematic Letterboxing / Pillarboxing**: Automatically adapts to any monitor aspect ratio (16:9, 16:10, 21:9 ultrawide, 4:3) with zero stretching or distortion.
- **Audio-Synchronized Playback**: Frame timing is locked to the audio clock (`timeSeconds * FPS`), ensuring audio and video never drift out of sync.
- **Window Resize Safe**: Resizing the window or toggling F11 fullscreen does not restart or desync playback.
- **Zero GC Lag**: Pre-allocated texture identifiers table eliminating per-frame allocations on the render thread.
- **Cinematic Overlay**: Subtle bottom progress indicator and an introductory title that smoothly fades out after 3.5 seconds for complete visual immersion. Press `ESC` at any time to skip.

## Commands (Unchanged)
```
/videoplay <video name> <player>
/videostop
```

Example:
```
/videoplay antag Steve
```

## How to Build
1. Make sure **Java 21** or newer is installed on your system (`java -version`).
2. Open a terminal in the mod folder:
   - On Linux / macOS:
     ```bash
     ./gradlew build
     ```
   - On Windows (Command Prompt or PowerShell):
     ```cmd
     gradlew.bat build
     ```
3. Once the build completes, find the compiled mod jar in:
   ```
   build/libs/antagvideo-1.0.0.jar
   ```
4. Copy the jar into your `.minecraft/mods` folder along with Fabric Loader for version 26.2 and Fabric API.

## Customizing Framerate
The mod includes all 343 frames at 8 FPS (~15 MB).
If you want to re-extract at 12 FPS (514 frames):
```bash
ffmpeg -i src/main/resources/assets/antagvideo/video_optimized.mp4 -vf "fps=12,scale=854:392" -q:v 3 src/main/resources/assets/antagvideo/textures/frames/%04d.jpg -y
```
And update `TOTAL_FRAMES = 514;` in `VideoRenderer.java`.
