# Antag Video Cutscene Mod (Fabric 26.2)

Fullscreen video player for the Antag vs FlameFrags cutscene.

## Commands
```
/videoplay <video name> <player>
/videostop
```

Example:
```
/videoplay antag Steve
```

ESC to skip.

## Current State (what you see right now)
- Black fullscreen background
- Cycles 4 sample frames from the video
- Green progress bar at the bottom
- Audio plays (the OGG)
- Text overlay showing video name + player + time
- Auto-closes after ~43 seconds

**This is only a preview.** Real smooth video needs the other AI to finish the frame loading / decoder.

## What to send to the AI that will finish the mod

Copy-paste this prompt:

---
I have a Fabric 26.2 Minecraft mod source for a fullscreen video cutscene player.

The mod is already set up with:
- Command: /videoplay <video name> <player>
- Optimized MP4 (video_optimized.mp4) and OGG audio inside assets
- 343 high-quality JPEG frames extracted at 8 FPS (854x392) available in the original project (or re-extract them)
- VideoPlayerScreen + VideoRenderer

Your job:
1. Make VideoRenderer load and cycle the real sequential frames (0001.jpg → 0343.jpg) smoothly at ~8-12 FPS so it looks like a real video.
2. Or implement a proper video decoder for the MP4 if you prefer (javacv / bytedeco is ok if size stays reasonable).
3. Keep total mod size under 100 MB.
4. Make it look cinematic and high quality (correct aspect ratio, letterboxing if needed, no stretch artifacts).
5. Keep the /videoplay <name> <player> command exactly as is.
6. Make sure audio stays in sync.

The frames are already extracted in the source folder under frames/ (or re-generate with ffmpeg -vf "fps=8,scale=854:392" -q:v 3).

Please output the completed VideoRenderer.java and any other files that need changing, and a short note on how to build/run it.
---

## How to build (after the other AI finishes)
1. Install JDK 21
2. In the mod folder run: `./gradlew build`
3. The jar will be in `build/libs/`
4. Put the jar in your `.minecraft/mods` folder (Fabric 26.2)

## File size
- Optimized video: ~11 MB
- Audio: ~0.7 MB
- Full frame set (if included): ~12-20 MB
- Total well under 100 MB
